class Dict2:
    def __init__(self):
        self.keys = []
        self.values = []

    def __setitem__(self, key, value):
        if key in self.keys:
            index = self.keys.index(key)
            self.values[index] = value
        else:
            self.keys.append(key)
            self.values.append(value)

    def __getitem__(self, key):
        if key in self.keys:
            index = self.keys.index(key)
            return self.values[index]
        else:
            raise KeyError(f"Key '{key}' not found")

    def __iter__(self):
        return iter(self.keys)

# Custom exception class
class CustomKeyError(Exception):
    pass
if __name__ == "__main__":
    # Create an instance of Dict2
    obj = Dict2()

    # Perform some operations
    obj['a'] = 1
    obj['b'] = 2
    obj['c'] = 3

    # Print the values for demonstration
    print(obj['a'])  # Output: 1
    print(obj['b'])  # Output: 2
    print(obj['c'])  # Output: 3
